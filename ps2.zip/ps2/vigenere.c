

#include <stdio.h>
#include <string.h>
#include <cs50.h>
#include <ctype.h>

char encry(char token, int key);

int main(int argc, string argv[]) {

    // Variable declarations
    bool success = false;
    string key = "";
    int len = 0;
    string text = "";
    int text_length;
    int count = 0;

    do
    {
         
        if(argc != 2)
        {
            printf("Incorrect keyword.\n");
            return 1;
        }
        else if(argv[1])
        {
            int length = strlen(argv[1]);
            for(int i = 0; i < length; i++)
            {
                if(!isalpha(argv[1][i]))
                {
                    // We accept only letters as input. 
                    printf(" illegal characters.\n");
                    return 1;
                }
                else
                {
                    // All good, input can be accepted as key.
                    success = true;
                    key = argv[1];
                }
            }
        }
    } while(!success);
    
    // We check for the length of the keyword and define an array with that length.
    len = strlen(key);
    int array[len];

    // The letters in the keyword array should be converted to numbers
    // starting from A = 0 to Z = 25 ignoring case.
    for(int i = 0; i < len;i++)
    {
        array[i] = toupper(key[i]) - 65;
    }

    // Read in user text and calculate its length.
    text = GetString();
    text_length = strlen(text);

    for (int i = 0; i < text_length; i++)
    {
        // If input at given position is not letter, just mirror it.
        if(!isalpha(text[i]))
        {
            printf("%c",text[i]);
        }
        // Process input.
        else
        {
            printf("%c", encry(text[i], array[count]));

            // Increase the position counter for the keycode array.  
            if(count < len - 1)
            {
                count++;
            }
            else
            {
                count = 0;
            }
        }
    }

    // Be a nice citizen and exit cleanly.
    printf("\n");
    return 0;
}

/*
    This function applies a case-sensitive caeser cipher for a single
    character using the supplied key.
*/
char encry(char token, int key)
{
    if(islower(token))
    {
        return ((((token - 97)+key)%26)+97);
    }
    else
    {
        return ((((token - 65)  +key)%26)+65);
    }
}
