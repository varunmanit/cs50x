
/* programe to take key and plain text from command line and change the plain tgext into cipher text using caeer cipher method */

#include<stdio.h>
#include<string.h>
#include<cs50.h>
#include<stdlib.h>
# define MAX 26

int main(int argc,string argv[])
{
   //variable declaration
   bool sucess=false;
  int i=0,x,k;
   string s="";
   do
   {
      if(argc!=2)
      {
         printf("Some error");
         return 1;
      }
      else
      {
         k=atoi(argv[1]);
         sucess=true;
      }
   }
   while(!sucess);
   s=GetString();
   while(s[i]!='\0')
   {
      x=(int)s[i];
      if(s[i]>='a' && s[i]<='z')
      {
         x=x-97;
         x=(x+k)%MAX;
         x=x+97;
         s[i]=(char)x;
      }
      else if(s[i]>='A' && s[i]<='Z')
      {
         x=x-65;
         x=(x+k)%MAX;
         x=x+65;
         s[i]=(char)x;
         
      }      
      printf("%c",s[i]);
   i++;
   }
printf("\n");
return 0;
}
