/* Program to print the first character of name in capitalize form */ 
#include<stdio.h> 
#include<string.h>
#include<cs50.h>

void print_CAP(char a)
{
    if(a>='a'&& a<='z')
    printf("%c",(a-32));
    else
    printf("%c",a);
}

int main(void)
{
    string s;
    int len,i;
    //take input from user
    s=GetString();
    //length of the string
    len=strlen(s);
    
    if(len>0)
    {
        print_CAP(s[0]);
        
        i=1;
        while(s[i]!='\0')
        {
            if(s[i]==' ')
            {
                i++;
            print_CAP(s[i]);
            }
            i++;
        }
        printf("\n");
    }
    
}    
    
    
