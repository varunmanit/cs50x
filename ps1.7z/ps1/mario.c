#include<stdio.h>
#include<cs50.h>
int main(void)
{
    int h,c_hash,space,i;
    do
    {
        printf("Height: ");
        h=GetInt();
    }
    while(h<0||h>23);
    if(h>0 && h<=23)
    {
        c_hash=2;
        space=(h+1)-(c_hash);
        while(h--)
        {
        for(i=0;i<space;++i)
        printf(" ");
        for(i=0;i<c_hash;++i)
        printf("#");
        printf("\n");
        c_hash++;
        space--;
        }
    }
}