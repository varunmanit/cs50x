#include<stdio.h>
#include<cs50.h>
#include<math.h>
int main(void)
{
    float f;
    int g_cent,count=0;
    do
    {
        printf("O hai! How much change is owed?\n");
        f=GetFloat();
    }
    while(f<0);
    if(f>0)
    {
        g_cent=(int)round(f*100);
        count+=(g_cent/25);
        g_cent%=25;
        count+=(g_cent/10);
        g_cent%=10;
        count+=(g_cent/5);
        g_cent%=5;
        count+=g_cent;
        printf("%d\n",count);
        
    }
}